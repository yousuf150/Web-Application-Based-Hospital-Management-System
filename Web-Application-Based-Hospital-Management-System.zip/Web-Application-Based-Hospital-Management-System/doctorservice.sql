-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2020 at 03:39 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctorservice`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` int(15) NOT NULL,
  `profile_photo` varchar(255) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `phone`, `profile_photo`, `password`) VALUES
(1, 'Yousuf', 'princeyousuf150@gmail.com', 1742942150, 'ryhan0 (1).jpg', '535649b032069346b35d260a6b086bc0'),
(2, 'sayad', 'shayadryhan@gmail.com', 1798487684, 'ryhan0 (1).jpg', '88a71c00c3134ff89f85f2d56327a8ac'),
(5, 'another', 'another@gmial.com', 1864553547, 'upload/1987958c0b.jpg', '88a71c00c3134ff89f85f2d56327a8ac'),
(6, 'Mr. Sabbir Hossain ', 'sabbir@gmail.com', 1706735774, 'upload/4b2a0c5771.png', '8b9ddb14103d13348b3122642e2d87e8'),
(7, 'Md. asiq', 'hmnayemislam4921@gmail.com', 1780343374, 'upload/2785d8438e.jpg', '535649b032069346b35d260a6b086bc0');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `userdata_id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `your_name` varchar(64) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `dr_degree` varchar(64) NOT NULL,
  `hospital_name` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `test_cat` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`userdata_id`, `user_id`, `your_name`, `doctor_name`, `dr_degree`, `hospital_name`, `date`, `test_cat`, `image`) VALUES
(4, 1, 'Md yousuf Hossen', 'Prof . Dr. Golam Muin Uddin', 'MBBS, FCPS,FRCP', 'Bangabandhu Sheikh Mujib Medical University', '2020-10-01', 'Blood Test Report', 'Bristy.jpg'),
(14, 1, 'Md Yousuf Hossen', 'dr mamudul hasan', 'frcs', 'dhaka medicale', '2020-06-20', 'Blood Test Report', 'upload/36c48a6024.jpg'),
(15, 1, 'Md Mehedi Hasan', 'khondokar mostak', 'mbbs', 'BSMM', '2020-06-09', 'X-Ray', 'upload/cda9b98546.jpg'),
(16, 1, 'Md Mehedi Hasan ms', 'dr mamudul hasan', 'frcs', 'BSMM', '2020-06-19', 'Blood Test Report', 'upload/c7b10d8fa5.jpg'),
(17, 1, 'Gazi Ahad', 'Dr. Mahomudul Hassan', 'mbbs', 'dhaka medicale', '2020-10-31', 'X-Ray', 'upload/348645c6e5.jpg'),
(18, 1, 'Gazi Ahad', 'Dr. Mahomudul Hassan', 'mbbs', 'dhaka medicale', '2020-10-31', 'X-Ray', 'upload/8a08429d09.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`userdata_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `userdata_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
