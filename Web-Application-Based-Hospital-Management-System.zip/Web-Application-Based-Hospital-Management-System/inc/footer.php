
  <section class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-3">
                    <img src="image/accident.jpg" alt="">
                </div>
                <div class="col-md-2">
                    <div class="appoinment">
                        <h6>APPOINTMENT :</h6>
                        <p>10678<br />(02) 55037242<br />09606-276555</p>
                    </div>

                </div>
                <div class="col-md-1"></div>
                <div class="col-md-2">
                    <div class="contuct">
                        <h6>Please give your Feedback:</h6>
                        <p>Md Sabbir Hossain<br />sabbirhossain.cse163@gmail.com<br />call:+8801767056278</p>
                    </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-2">
                    <div class="last">
                        <h6> OUR INFO CENTER:</h6>
                        <p>Apollo: 01713-047461<br />ad-din: 01766555889<br /> popular:017223555888 <br />al-helal :01933666888<br />square: 01713141447<br /></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
  
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script type="text/javascript">
        $('[data-fancybox="images"]').fancybox({
          buttons : [ 
            'slideShow',
            'share',
            'zoom',
            'fullScreen',
            'close'
          ],
          thumbs : {
            autoStart : true
          }
        });

    </script>

</body>
</html>