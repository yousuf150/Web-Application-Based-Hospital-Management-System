<?php include "lib/confiq.php" ?>
<?php include "lib/database.php";
    $db = new Database();
    $Err1 = "" ;
    $Err2 = "" ;
    $ErrMail = "" ;

?>

<?php
    if($_SERVER['REQUEST_METHOD'] =='POST'){
        $email = $_POST['email'];
        $pass = $_POST['password'];

        if(empty($email)){
           $Err1 = "The email field is required";
        }else if(empty($pass)){
            $Err2 = "The Password field is required";
        }else{
          $password = md5($pass);
          $string = "SELECT * FROM users WHERE email='$email' AND password='$password' limit 1 ";
          $result = $db->select($string);
          
          if($result){
            $show = $result->fetch_assoc();
            session_start();

            $_SESSION['user_id'] = $show['user_id'];
            $_SESSION['email'] = $show['email'];
             
            header('location:user_information.php');
          }else{
             $ErrMail = "Invalid mail or Password" ;
          }
        }


    }

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div id="login-box">
  <div class="left">
    <h1>Signin</h1>
    <span class="" style="color:red; font-weight:bold;"><?php echo $Err1?></span>
    <span class="" style="color:red; font-weight:bold;"><?php echo $Err2?></span>
    <span class="" style="color:red; font-weight:bold;"><?php echo $ErrMail?></span>
    <form action="" method="post">
        <input type="text" name="email" placeholder="Username Or Email" />
        <input type="password" name="password" placeholder="Password" />
        
        <input type="submit" name="signup_submit" value="Sign In" />
        <a href="registrations.php"><h4>Create an Account</h4></a>
    </form>
    
    
  </div>
  
  <div class="right">
    <span class="loginwith">Sign in with<br />social network</span>
    
    <button class="social-signin facebook">Log in with facebook</button>
    <button class="social-signin twitter">Log in with Twitter</button>
    <button class="social-signin google">Log in with Google+</button>
    
  </div>
  <div class="or">OR</div>
  
</div>
</body>
</html>