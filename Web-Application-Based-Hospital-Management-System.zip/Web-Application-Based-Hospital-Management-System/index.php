<?php include "inc/header.php" ?>
        <div class="search-bar-area">
            <div class="contianer">
                <div class="row">
                    <div class="col-md-2 form-location col-md-offset-2 nopadding">
                        <div class="location">
                            <div class="form_group ">
                                <select type="text" class="form-control doctor-control-form">
                                    <option value="" hidden selected disabled>Select Cities...</option>
                                    <option value="">Rajshahi</option>
                                    <option value="">Rangpur</option>
                                    <option value="">Chittagong</option>
                                    <option value="">Barisal</option>
                                    <option value="">Khulna</option>
                                    <option value="">Sylhet</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 from-doctor nopadding">
                        <div class="doctor">
                            <div class="form_group">
                                <select type="text" class="form-control doctor-control-form">
                                    <option value="" hidden selected disabled>I am looking for</option>
                                    <option value="">Doctor</option>
                                    <option value="">Hospital</option>
                                    <option value="">Blood Donor</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 form-hospital nopadding">
                        <div class="form_group">
                            <input type="text" class="form-control doctor-control-form" placeholder="Search by Doctor Name, Hospital name" name="search">
                        </div>
                    </div>
                    <div class="col-md-1 nopadding">
                        <form>
                            <div class="forom_group">
                                <button type="submit" class="button"><i class="fa fa-search"></i></button>
                            </div>     
                        </form>
                    </div>  
                </div>
            </div>   
        </div>
    <section class="slide-area">
        <div class="overlay"></div>
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="image/Apallo2.jpg" alt="...">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="slider-content">
                                        <h2>Biggest hospital in bangladesh</h2>
                                        <a href="https://www.apollodhaka.com/"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <img src="image/Squre1.jpg" alt="...">
                    <div class="carousel-caption">
                        <div class="slider-content">
                            <h2>Biggest hospital in bangladesh</h2>
                            <a href="https://www.squarehospital.com/"></a>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <img src="image/Ibne%20cina%204.jpg" alt="...">
                    <div class="carousel-caption">
                        <div class="slider-content">
                            <h2>Biggest hospital in bangladesh</h2>
                            <a href="https://www.ibnsinatrust.com/"></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Controls -->

        </div>
    </section>
    <section class="">
        <div class="news-title">
            <h2>
                <marquee><a href="">আবরার হত্যা নিয়ে বিবৃতি দেওয়ায় মিয়া সেপ্পোকে ডেকে অসন্তোষ প্রকাশ</a></marquee>
            </h2>
        </div>
    </section>
    
<!--    About-service-item -->
    
    <div class="service-area health-bg">
           <h1>Our Health tips</h1>
            <div class="service-single-item owl-carousel">
                <div class="service-item">
                   <img src="image/health-1.jpg" alt="">
               </div> 
               <div class="service-item">
                   <img src="image/health-1.jpg" alt="">
               </div> 
               <div class="service-item">
                   <img src="image/health-1.jpg" alt="">
               </div> 
               <div class="service-item">
                   <img src="image/health-1.jpg" alt="">
               </div> 
            </div>
    </div>   
   
<!--    About-service-item end -->
 <?php include "inc/footer.php" ?>