
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="assets/css/registraion.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<?php 
    include "lib/confiq.php";
    include "lib/database.php";
    $db = new Database();

    $emp_error = "";
    $pass_error = "";
    $valid_mail = "";
    $ins_succ = "";
     
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $pass = md5($_POST['password']);
        $confirm_pass = md5($_POST['confirm_pass']);

        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $div = explode('.', $file_name);

        $file_ext = strtolower(end($div));
        $uniqe_image = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$uniqe_image;

        if(empty($name) || empty($email) || empty($phone) || empty($file_name) || empty($pass) || empty($confirm_pass)){
            $emp_error = "No Field can be empty"; 
        }elseif($file_size<1000){
            echo "<span style='color:red; margin-left: 20px;'>Please upload the image lessthan 1 byte</span>";
        }elseif(in_array($file_ext, $permited)===false){
            echo "<span>You can upload only:-".implode(', ',$permited )."</span>";
        }else if($pass != $confirm_pass){
            $pass_error ="The password dosen't match";
        }

        if($emp_error=="" && $pass_error==""){
            $string ="SELECT * FROM users WHERE email ='$email' ";
            $result = $db->select($string);

            if($result){
                $valid_mail = "This mail Already been use" ;
            }else{
                move_uploaded_file($file_tmp, $uploaded_image);
                $sql = "INSERT INTO users (name, email, phone, profile_photo, password)VALUES('$name', '$email', '$phone', '$uploaded_image', '$pass')";
                $db_insert = $db->insert($sql);
                
                if($db_insert){
                    $ins_succ = "db insert successfully " ;
                }
                
            }

        }
    }

?>

<div class="container register">
        <div class="row">
            <div class="col-md-3 register-left">
                <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
                <h3>Welcome</h3>
                <p>To registration our site !</p>
                <a href="login.php"><input type="submit" name="" value="Login"/><br/></a>
            </div>
            <div class="col-md-9 register-right">
                <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Doctor</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <h3 class="register-heading">Apply as a User</h3>
                        <h5 class="register-heading"><span class="" style="color:red; font-weight:bold"><?php echo $emp_error ; ?></span></h5>
                        <h5 class="register-heading"><span class="" style="color:green; font-weight:bold"><?php echo $ins_succ ; ?></span></span></h5>
                        <h5 class="register-heading"><span class="" style="color:red; font-weight:bold"><?php echo $valid_mail; ?></span></span></h5>
                        <h5 class="register-heading"><span class="" style="color:red; font-weight:bold"><?php echo $pass_error; ?></span></span></h5>    
                      
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="row register-form">
                                    
                                <div class="col-md-6">
                                   
                                    <div class="form-group">
                                        <label for="name">Your Full Name</label>
                                        <input type="text" id="name" class="form-control" name="name" placeholder="User Full Name *" value="" />
                                    </div>
                                    <div class="form-group">
                                        <label for="phonenumber">Your Phone Number</label>
                                        <input type="text" id="phonenumber" maxlength="15" name="phone" class="form-control" placeholder="Your Phone *" value="" />
                                    </div>

                                    <div class="form-group">
                                         <label for="passwordid">Enter your password</label>
                                         <input type="password" id="passwordid" name="password" class="form-control" placeholder="Password" value="" />
                                     </div>

                                    <div class="form-group">
                                        <div class="maxl">
                                            <label class="radio inline"> 
                                                <input type="radio" name="gender" value="male" checked>
                                                <span> Male </span> 
                                            </label>
                                            <label class="radio inline"> 
                                                <input type="radio" name="gender" value="female">
                                                <span>Female </span> 
                                            </label>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Your Email</label>
                                        <input type="email" id="email" class="form-control" name="email" placeholder="Email *" value="" />
                                    </div>
                                    <div class="">
                                        <label for="phonenumber">Your Profile photo</label>
                                    </div>
                                    <div class="custom-file ">
                                        <input type="file" id="logo" name="image" class="custom-file-input">
                                        <label for="logo" class="custom-file-label text-truncate">Your profile photo</label>
                                    </div>

                                    <div class="form-group">
                                         <label for="confirm">Confirm password</label>
                                         <input type="password" id="confirm" name="confirm_pass" class="form-control" placeholder="Password" value="" />
                                     </div>

                                    <input type="submit" class="btnRegister" name="submit"  value="Submit"/>
                                </div>
                            </div>
                        </form>
                 
                    </div>
                    <div class="tab-pane fade show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <h3  class="register-heading">Apply as a Doctor</h3>
                        <div class="row register-form">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="First Name *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Password *" value="" />
                                </div>
                                
                                <div class="form-group">
                                    <div class="maxl">
                                        <label class="radio inline"> 
                                            <input type="radio" name="gender" value="male" checked>
                                            <span> Male </span> 
                                        </label>
                                        <label class="radio inline"> 
                                            <input type="radio" name="gender" value="female">
                                            <span>Female </span> 
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="lastname" class="form-control" placeholder="Last Name *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" minlength="10" maxlength="10" name="txtEmpPhone" class="form-control" placeholder="Your Phone *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control"  placeholder="Confirm Password *" value="" />
                                </div>
                                
                                <input type="submit" class="btnRegister"  value="Register"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>