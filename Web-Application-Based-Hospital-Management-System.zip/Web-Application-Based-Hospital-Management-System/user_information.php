<?php include "lib/confiq.php"?>
<?php include "lib/database.php" ;
    $db = new Database();
    session_start();
    $Err_mess = "" ;
    $succ = "" ;

?>
<?php 

    if(!isset($_SESSION['user_id'])){
        header('location:login.php');
    }
    $userid = $_SESSION['user_id'];

?>
   
<?php
    if($_SERVER['REQUEST_METHOD']=='POST'){
        
        $your_name = $_POST['your_name'];
        $doctor_name = $_POST['doctor_name'];
        $degree_name = $_POST['degree'];
        $hospital_name = $_POST['hospital_name'];
        $press_date = $_POST['pressription'];
        $test_cat = $_POST['test_cat'];
        $userid = $_SESSION['user_id'];

        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $div = explode('.', $file_name);

        $file_ext = strtolower(end($div));
        $uniqe_image = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$uniqe_image;


    if(empty(($your_name) || $doctor_name) || empty($degree_name) || empty($hospital_name) || empty($press_date) || empty($test_cat) || empty($file_name) || empty($userid)){
            $Err_mess = "No field can be empty"; 
        }elseif($file_size<1000){
            echo "<span style='color:red; margin-left: 20px;'>Please upload the image lessthan 1 byte</span>";
        }elseif(in_array($file_ext, $permited)===false){
            echo "<span>You can upload only:-".implode(', ',$permited )."</span>";
        }else{
            move_uploaded_file($file_tmp, $uploaded_image);
            $string = "INSERT INTO user_data (user_id, your_name, doctor_name, dr_degree, hospital_name, date, test_cat, image)VALUES('$userid','$your_name','$doctor_name','$degree_name','$hospital_name','$press_date', '$test_cat','$uploaded_image')" ;

            $result = $db->insert($string);
            if($result){
                $succ = "Data Insert Successfully";
            }
        }
        

    }
?>


<html>
<head>
    <title>Health Vault Everyone</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="style.css">

</head>
<body>    
    <div class="header-top">
        <div class="container">
            <div class="row">
                <header>
                    <nav id='cssmenu'>
                        <div class="logo"><a href="index.php"><img src="image/logo.png"></a></div>
                        <div id="head-mobile"></div>
                        <div class="button"></div>
                        <ul class="mainmenu">
                        <li class='active'><a href='index.php'>HOME</a></li>
                        <li><a href='#'>ABOUT US</a></li>
                        <li><a href='#'>PRODUCTS</a>
                        <ul>
                            <li><a href='#'>Product 1</a>
                                <ul>
                                    <li><a href='#'>Sub Product</a></li>
                                    <li><a href='#'>Sub Product</a></li>
                                </ul>
                            </li>
                            <li><a href='#'>Product 2</a>
                                <ul>
                                    <li><a href='#'>Sub Product</a></li>
                                    <li><a href='#'>Sub Product</a></li>
                                </ul>
                            </li>
                        </ul>
                        </li>
                        <li><a href='user_information.php'>SERVICE</a></li>
                        <li><a href='#'>GALLERY</a></li>
                        <li><a href='signout.php'>SIGNOUT</a></li>
                        </ul>
                    </nav>
                </header>
            </div>  
        </div>
    </div>
    <div class="inform-top">
        <div class="container">
            <div class="row">
                <div class="profile">
                    <div class="col-md-8">
                        <h2>You Put your Prescription here </h2>
                        
                    </div>  
                    <div class="col-md-4">
                        <div class="profile-btn">
                            <a href="" class="btn btn-primary" data-target="#exampleModal" data-toggle="modal">Create Your profile</a>

                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title mes-modal" id="exampleModalLabel">New message</h4>
                                </div>
                                <div class="modal-body">
                                    <span style="color:Green; font-weight:bold;"><?php echo $succ ?></span>
                                    <span style="color:red; font-weight:bold;"><?php echo $Err_mess ?></span>
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="recipient-name" class="control-label label-modal">Your Name</label>
                                            <input type="text" class="form-control" name="your_name" id="recipient-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="recipient-name" class="control-label label-modal">Doctor Name</label>
                                            <input type="text" class="form-control" name="doctor_name" id="recipient-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="recipient-name" class="control-label label-modal">Dr. Degree Name</label>
                                            <input type="text" class="form-control" name="degree" id="recipient-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="recipient-name" class="control-label label-modal">Hospital Name</label>
                                            <input type="text" class="form-control" name="hospital_name" id="recipient-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="recipient-name" class="control-label label-modal">prescription Data</label>
                                            <input type="date" class="form-control" name="pressription" id="recipient-name">
                                        </div>
                                        <div class="form-group">
                                            <label for="message-text " class="control-label label-modal">Select Testing category</label>
                                            <select class="form-control" name="test_cat">
                                                <option class="hidden"  selected disabled>Testing category name</option>
                                                <option>X-Ray</option>
                                                <option>ECG Report</option>
                                                <option>Blood Test Report</option>
                                            </select>
                                        </div>
                                        <div class="custom-file">
                                             <label class="custom-file-label  label-modal" for="customFileLang">Your prescripe images </label>
                                            <input type="file" class="custom-file-input text-truncate" name="image" id="customFileLang" lang="es">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default close-modal-btn" data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary sent-modal-btn" name="send">Send message</button>
                                        </div>
                                    </form>
                                </div>
                                
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>   
    <?php
        $sql = "SELECT * FROM users WHERE user_id = '$userid'";
        $result = $db->select($sql);

        if($result){
            while($show = $result->fetch_assoc()){
                ?>
   
    <div class="container">
        <div class="row">
            <div class="user-personal-pro">
                <div class="col-md-3 col-md-offset-1">
                    <div class="user-ph">
                        <img src="<?php echo $show['profile_photo']; ?>" alt="images"> 
                    </div> 
                </div>
                <div class="col-md-7 col-md-offset-1">
                        <div class="userdata user-info">
                            <h2>Welcome To Visit Your Profile</h2>
                            <table>
                                <tr>
                                    <td><h4>Name </h4></td>
                                    <td class="sepe"> : </td>
                                    <td><h4> <?php echo $show['name'] ?></h4></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td class="sepe">: </td>
                                    <td><h6> Asst. Professor, Chest Medicine</h6></td>
                                </tr>
                                <tr>
                                    <td><h4>Phone Number </h4></td>
                                    <td class="sepe">: </td>
                                    <td><h5> <?php echo $show['phone'] ?></h5></td>
                                </tr>
                                <tr>
                                    <td><h4>Email Address </h4></td>
                                    <td class="sepe">: </td>
                                    <td><h5> <?php echo $show['email'] ?></h5></td>
                                </tr>
                                
                            </table>
                        </div> 
                    </div> 
            </div>
        </div>
    </div> 
    <?php  }
        }

    ?>
    <div class="container userdata-area">
    <?php 
        $string = "SELECT * FROM user_data WHERE user_id = '$userid'";
        $result = $db->select($string);

        if($result){
            while($read = $result->fetch_assoc()){
                ?>

        <div class="row userdata-br">
            <div class="col-md-6 col-md-offset-1 ">
                <div class="userdata">
                    <h2><?php echo $read['your_name']?> </h2>
                    <table>
                        <tr>
                            <td><h4>Doctor name </h4></td>
                            <td class="sepe"> : </td>
                            <td><h4> <?php echo $read['doctor_name']?></h4></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td class="sepe">: </td>
                            <td><h6> <?php echo $read['dr_degree']?></h6></td>
                        </tr>
                        <tr>
                            <td><h4>Hospital Name </h4></td>
                            <td class="sepe">: </td>
                            <td><h4> <?php echo $read['hospital_name']?></h4></td>
                        </tr>
                        <tr>
                            <td><h4>prescription Data </h4></td>
                            <td class="sepe">: </td>
                            <td><h4> <?php echo $read['date']?></h4></td>
                        </tr>
                        <tr>
                            <td><h4>Testing Category</h4></td>
                            <td class="sepe">: </td>
                            <td><h4> <?php echo $read['test_cat']?></h4></td>
                        </tr> 
                    </table>
                </div> 
            </div>
            <div class="col-md-4">
                <div class="pre_pho">
                    <a href="<?php echo $read['image']; ?>" data-fancybox="images" data-caption="Backpackers following a dirt trail">
                      <img  src="<?php echo $read['image']; ?>" alt="image">
                    </a>
                </div> 
            </div>
        </div>
        <?php 
            }
        }else{
            echo "<h2 style='color:blue'>No data Found.Please click the Create your profile button.<br> and store you prescription data</h2>";
        }
        ?>

    </div>

  <?php include "inc/footer.php" ?>